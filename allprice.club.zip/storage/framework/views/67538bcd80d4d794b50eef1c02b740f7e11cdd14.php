<div class="modal fade" id="editcategory" tabindex="-1" role="dialog" aria-labelledby="editcategory" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content p-4">
            <div class="modal-header border-0 mb-3">
                <h4 class="modal-title">Edit Category</h4>
                <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form class="theme-form" action="<?php echo e(route('category.ajax-update')); ?>" id="edit_category_form">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="col-form-label pt-0">Edit Category Name</label>
                    <input name="id" type="hidden" id="edit_category_id">
                    <input class="form-control" type="text" placeholder="e.g. Alibaba" name="name" id="edit_catgeory_name">
                </div>
                <div class="mb-3">
                    <label class="col-form-label pt-0">Category Image</label>
                    <div class="input-group">
                        <input accept="image/*" type="file" class="form-control" onchange="previewFile(event,'edit_catgeory_image_preview')" id="edit_category_image" name="catgeory_image" aria-describedby="inputGroupFileAddon04" aria-label="Upload">
                        <button class="btn btn-outline-primary" type="button" id="inputGroupFileAddon04">Upload</button>
                    </div>
                </div>
                <div class="mb-3">
                    <div class="product-img text-center">
                        <img class="img-fluid" src="<?php echo e(asset('assets/images/no-data-available.jpg')); ?>" id="edit_catgeory_image_preview" alt="product image">
                    </div>
                </div>
            </form>
            <div class="modal-footer border-0 text-center text-sm-end">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button class="btn btn-primary" id="update_category">Save Changes</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\allprice.club\resources\views/partials/modals/edit-category.blade.php ENDPATH**/ ?>