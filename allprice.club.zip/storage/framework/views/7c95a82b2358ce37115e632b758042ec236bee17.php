<div class="col-12">
    <div class="product-wrapper-grid">
        <div class="row">

            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-xl-3 col-sm-6">
                <div class="card">
                    <div class="product-box">
                        <div class="product-img">
                            <div class="ribbon ribbon-info ribbon-right"><?php echo e($product->value); ?> <?php echo e($product->type); ?></div>
                            <img src="<?php echo e(asset($product->image)); ?>" alt="product image">
                            <div class="product-hover">
                                <ul>
                                    <li>
                                        <button class="btn" type="button" data-bs-toggle="modal" data-bs-target="#editProductModal">
                                            <i data-feather="edit"></i>
                                        </button>
                                    </li>
                                    <li class="bg-primary">
                                        <button class="btn text-white" type="button" data-bs-toggle="modal" data-bs-target="#product-modal-3">
                                            <i data-feather="plus"></i>
                                        </button>
                                    </li>
                                    <li class="bg-info">
                                        <a href="<?php echo e(asset($product->image)); ?>" data-lightbox="product-image" data-title="Beautiful Lamp" data-alt="full view" class="btn text-white">
                                            <i data-feather="eye"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="product-details">
                            <h4><?php echo e($product->name); ?></h4>
                            <div class="product-price">$<?php echo e($product->price); ?></div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <img src="<?php echo e(asset('assets/images/no-data-found.png')); ?>" alt="product image">
            <?php endif; ?>


        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\allprice.club\resources\views/products/partials/product-list.blade.php ENDPATH**/ ?>