<div class="col-12">
    <div class="product-wrapper-grid" id="shop-list">
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-xl-3 col-sm-6">
                <div class="card">
                    <div class="product-box">
                        <div class="product-img">
                            <img class="img-fluid" src="<?php echo e(asset($shop->image)); ?>" alt="product image">
                            <div class="product-hover">
                                <ul>
                                    <li>
                                        <button data-url="<?php echo e(route('shops.edit',$shop->id)); ?>" class="btn" type="button" data-bs-toggle="modal" data-bs-target="#editShop" data-bs-original-title="" title="">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit">
                                                <path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"></path>
                                                <polygon points="18 2 22 6 12 16 8 16 8 12 18 2"></polygon>
                                            </svg>
                                        </button>
                                    </li>
                                    <li class="bg-danger">
                                        <form method="POST" action="<?php echo e(route('shops.destroy',$shop->id)); ?>">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button class="btn delete-product" type="button" onclick="_gaq.push(['_trackEvent', 'example', 'try', 'delete-product']);" data-bs-original-title="" title="">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash-2">
                                                    <polyline points="3 6 5 6 21 6"></polyline>
                                                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                                    <line x1="10" y1="11" x2="10" y2="17"></line>
                                                    <line x1="14" y1="11" x2="14" y2="17"></line>
                                                </svg>
                                            </button>
                                        </form>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="product-details text-center ">
                            <h4><?php echo e($shop->name); ?></h4>
                        </div>

                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <img src="<?php echo e(asset('assets/images/no-data-found.png')); ?>" alt="product image">
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\allprice.club\resources\views/shop/partials/shop-list.blade.php ENDPATH**/ ?>