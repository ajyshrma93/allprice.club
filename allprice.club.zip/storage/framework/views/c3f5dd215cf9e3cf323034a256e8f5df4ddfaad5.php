<?php $__env->startSection('content'); ?>

<div class="page-body">
    <div class="container-fluid">
        <div class="page-title">
            <div class="row">
                <div class="col-5">
                    <h3>Category List</h3>
                </div>
                <div class="col-7">
                    <div class="create-new-items justify-content-end">
                        <button class="btn btn-primary d-md-none" type="button" data-bs-toggle="modal" data-bs-target="#add_catgeory_modal">
                            <i data-feather="plus"></i>
                            <span class="ms-2">Add New Category</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Container-fluid starts-->
    <div class="container-fluid">
        <div class="row">
            <!-- new product form start -->
            <div class="col-12 d-none d-md-flex w-100">
                <div class="card w-100">
                    <div class="card-header">
                        <h5><a href="#">Add new Category</a></h5>
                        <span>Please fill up the form below to add new Category</span>
                    </div>
                    <form method="POST" action="<?php echo e(route('category.store')); ?>" class="theme-form" enctype="multipart/form-data">

                        <div class="card-body">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label class="col-form-label pt-0">Enter Category</label>
                                        <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" type="text" placeholder="Category">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6 mt-md-0 mt-3">
                                        <label class="col-form-label pt-0">Category Image</label>
                                        <div class="input-group">
                                            <input type="file" name="category_image" class="form-control" id="inputGroupFile04" aria-describedby="inputGroupFileAddon04" aria-label="Upload">
                                            <button class="btn btn-outline-primary" type="button" id="inputGroupFileAddon04">Upload</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer text-center text-sm-end">
                            <button type="submit" class="btn btn-primary">Add Category</button>
                            <button class="btn btn-secondary">Cancel</button>
                        </div>
                    </form>

                </div>
            </div>
            <!-- new product form end -->

            <!-- product cards view start -->
            <?php echo $__env->make('category.partials.category-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- product cards view end -->
        </div>
    </div>
    <!-- Container-fluid Ends-->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modals'); ?>

<?php echo $__env->make('partials.modals.add-category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.modals.edit-category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\allprice.club\resources\views/category/index.blade.php ENDPATH**/ ?>